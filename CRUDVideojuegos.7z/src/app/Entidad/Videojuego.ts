export class Videojuego {
    id: number;
    nombre: String;
    marca: String;
    genero: String;
    precio: number;
}